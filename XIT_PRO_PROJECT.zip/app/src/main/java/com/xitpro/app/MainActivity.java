
package com.xitpro.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String SECRET_CODE = "XIT123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button confirmButton = findViewById(R.id.confirm_button);
        EditText codeInput = findViewById(R.id.code_input);

        confirmButton.setOnClickListener(v -> {
            String enteredCode = codeInput.getText().toString();
            if (enteredCode.equals(SECRET_CODE)) {
                startActivity(new Intent(this, PanelActivity.class));
            } else {
                Toast.makeText(this, "Código inválido", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
